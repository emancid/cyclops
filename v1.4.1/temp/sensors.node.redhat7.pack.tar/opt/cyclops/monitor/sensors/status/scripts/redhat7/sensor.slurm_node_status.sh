#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="slurm_node_status"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_hostname=$( hostname -s )

_sensor_status=$(sinfo -n $_hostname | awk '$2 == "up" { print $5 }' 2> /dev/null | sort -u )

case $_sensor_status in
	*idle*)
	_sensor_status="UP idle"
	;;
	*drng*)
	_sensor_status="MARK go to drain"
	;;
	*drain*)
	_sensor_status="FAIL maintenance"
	;;
	*alloc*|*mix*)
	_sensor_status="OK working"
	;;
	*comp*)
	_sensor_status="MARK completing"
	;;
	*down*)
	_partitions=$(sinfo -n $_localhost | awk '$2 == "up" && $5 ~ "down" { print $1 }' 2> /dev/null  )
	_sensor_status="DOWN down - "$_partitions
	;;
	*"n/a"*)
	_sensor_status="DISABLE not configured"
	;;
	"")
	_sensor_status="FAIL not comm"
	;;
	*)
	_sensor_status="UNKN unknown status"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
