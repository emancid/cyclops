#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="log_err"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_log_file="/var/log/syslog"
_time_threshold=300
_now_time=$( date +%s )
_log_err_num=$( cat $_log_file | awk -v _t="$_now_time" -v _th="$_time_threshold" 'BEGIN { _to=_t-_th ; _err=0 ; IGNORECASE=1 } $1 > _to && $1 < _t && $0 ~ "ERR" { _err++ } END { print _err }' )

case "$_log_err_num" in
	0)
		_sensor_status="UP"
	;;
	[1-9])
		_sensor_status="MARK "$_log_err_num
	;;
	*)
		_sensor_status="UNKN"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
