#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="bios_log"
_sensor_status="CHECKING"

_bios_log=$(ipmitool sel list 2>/dev/null | wc -l)

if [ $_bios_log != 0 ]
then
	_sensor_status="FAIL "$_bios_log
else
	_sensor_status="UP"
fi

echo $_sensor_name":"$_sensor_status"@"
