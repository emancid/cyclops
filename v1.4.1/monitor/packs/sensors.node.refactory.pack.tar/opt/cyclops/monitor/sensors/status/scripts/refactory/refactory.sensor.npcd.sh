#!/bin/bash

/etc/init.d/npcd status | sed -e 's/stopped/\;DOWNnpcd\;/' -e 's/running/\;UP\;/' -e 's/npcd\ dead\ but\ pid\ file\ exists/\;DEAD\;/' | cut -d';' -f2
