#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

#COMENT#This sensor is adapted to BULL HPC SUIT, please modify egrep -v to filter or not desired filesystems

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="disk_space"
_sensor_status="CHECKING"

_space=`df -lT | egrep -v "iso9660" | grep "dev" | egrep "9[0-9]%|100%" | awk '{ print $NF" "$(NF-1) }' | tr '\n' ' '`

if [ -z "$_space" ]
then
	_sensor_status="UP"
else
	_sensor_status="FAIL "$_space
fi

echo $_sensor_name":"$_sensor_status"@"
