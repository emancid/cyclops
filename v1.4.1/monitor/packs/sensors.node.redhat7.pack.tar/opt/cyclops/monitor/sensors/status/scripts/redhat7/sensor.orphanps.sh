#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@
#PROCESS ORPHAN PROCESS DETECTOR
source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="orphanps"
_sensor_status="CHECKING"

_hostname=$( hostname -s )

_nodestatus=$( squeue -w $_hostname | grep -v JOBID | wc -l )

if [ "$_nodestatus" -eq 0 ]
then 
	_ps_orphan=$( ps aux | egrep -v "dbus|munge|ntp|root|rpc|USER" | wc -l )
	[ "$_ps_orphan" -eq 0 ] && _sensor_status="UP" || _sensor_status="MARK $_ps_orphan"
else
	_sensor_status="UP"
fi

echo $_sensor_name":"$_sensor_status"@"

