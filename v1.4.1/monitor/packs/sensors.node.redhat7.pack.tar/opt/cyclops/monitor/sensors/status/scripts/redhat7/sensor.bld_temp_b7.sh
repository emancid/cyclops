#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="bld_temp"
_sensor_status="CHECKING"

_bld_temp=$( ipmitool sensor | awk -F\| '$1 ~ "Blade Temp" || $1 ~ "CSP Temp" { print $2 * 100 / $10 }' | cut -d'.' -f1 )

case "$_bld_temp" in
	[0-9]|[1-7][0-9])
		_sensor_status="UP $_bld_temp%"
	;;
	8[0-9])
		_sensor_status="OK $_bld_temp%"
	;;
	1[0-9][0-9]|9[0-9])
	_sensor_status="DOWN $_bld_temp%"
	;;
	"")
	_sensor_status="DISABLE sensor miss"
	;;
	*)
	_sensor_status="UNKNOWN $_bld_temp"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"

