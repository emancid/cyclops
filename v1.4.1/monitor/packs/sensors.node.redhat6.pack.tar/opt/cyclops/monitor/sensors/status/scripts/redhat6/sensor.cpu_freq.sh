#!/bin/bash
#@HELP@ Empty Sensor to create correctly the monitor dashboard
#@SCOPY@
#@LOCAL@

_sensor_name="cpu_freq"
_sensor_status="NONE"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_cpu_real=$( cat /proc/cpuinfo | awk ' $0 ~  "model name" { sub(/GHz/,"",$NF) ; m[$NF]++ } END { for ( i in m ) { print m[i]";"i*1000 }}' )
_cpu_freq=$( cat /proc/cpuinfo  | awk -F\:  -v _cr="$_cpu_real"  '
	BEGIN { 
		split(_cr,c,";") ;
		_o="no data" ;
		_s="ok" ; 
 	} $1 ~ "cpu MHz" { 
		gsub( /^ /,"",$2 ) ; 
		gsub( /.000$/,"",$2 ) ; 
		a[$2]++ ; 
	} END { 
		for ( i in a ) { 
			if ( a[i] == c[1] ) { 
				if ( i >= c[2] ) {
					_o="UP "i
				} else {
				_o="MARK "i 
				} 
			} else if ( i != c[2] ) { 
				if ( i > c[2] ) { 
					if ( _s != "fail" ) { 
						_o="OK "a[i]"x"i 
					}
				} else { 
					_s="fail" ; _o="MARK "a[i]"x"i 
				}  
			}
		} print _o 
	}' )

_sensor_status=$_cpu_freq

echo $_sensor_name":"$_sensor_status"@"
