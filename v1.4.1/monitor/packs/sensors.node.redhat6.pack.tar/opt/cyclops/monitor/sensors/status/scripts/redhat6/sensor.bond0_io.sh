#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="bond0_io"
_sensor_status="CHECKING"

_netdev="bond0"
_warn_level="30"

_net_top=$( /sbin/ethtool $_netdev 2>/dev/null | awk '$0 ~ "Speed" { sub(/....$/,"",$2) ; print $2 }' )
_net_ini=$( awk -v _nd="$_netdev" '{ sub(/:/,"",$1) } $1 == _nd { print $2";"$10 }' /proc/net/dev )

sleep 2s

_net_end=$( awk -v _nd="$_netdev" '{ sub(/:/,"",$1) } $1 == _nd { print $2";"$10 }' /proc/net/dev )
_net_vel=$( echo "dummie" | awk -F\; -v _ini="$_net_ini" -v _end="$_net_end" -v _top="$_net_top" -v _wl="$_warn_level" '
	BEGIN { 
		split(_ini,i,";") ; 
		split(_end,e,";") ; 
		_top=(_top*1000*1000)/8 ; 
		_st="UP" ;
	} { 
		_in=int((( ( e[1]-i[1] )/2 * 100 ) / _top )) ; 
		_out=int((( ( e[2]-i[2] ) /2 * 100 ) / _top ))
	} END { 
		if ( _in > _wl || _out > _wl ) { _st="MARK" } ;
		print _st" "_in"/"_out }' )

_sensor_status=$_net_vel

echo $_sensor_name":"$_sensor_status"@"
