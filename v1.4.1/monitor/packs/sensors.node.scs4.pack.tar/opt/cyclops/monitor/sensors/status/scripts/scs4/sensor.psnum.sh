#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@
#UPPER PROCESS USER EXEC

_sensor_name="psnum"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_ps_num_user_list=$( ypcat passwd | grep 2000 | cut -d':' -f1 | tr '\n' '|' | sed 's/|$//' )
_ps_num=$( ps -eFl | awk '{ print $3 }' | sort | uniq -c | awk '$1 > 30 { print $0 }' | egrep "$_ps_num_user_list" | wc -l  )

case "$_ps_num" in
        0)
                _sensor_status="UP"
        ;;
        [1-9]*)
                _sensor_status="FAIL $_ps_num"
        ;;
        *)
                _sensor_status="UNKNOWN $_ps_num"
        ;;
esac

echo $_sensor_name":"$_sensor_status"@"

