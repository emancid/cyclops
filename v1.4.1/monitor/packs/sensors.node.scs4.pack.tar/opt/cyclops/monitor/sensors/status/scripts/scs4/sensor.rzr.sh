#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="rzr"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_hostname=$( hostname -s )
_sensor_status=$( [ -f "/opt/cyclops/local/etc/local.main.cfg" ] && echo "UP" || echo "DISABLE mis" )

[ "$_sensor_status" == "UP" ] && source /opt/cyclops/local/etc/local.main.cfg && _sensor_rzr_fam=$( cut -d';' -f1  $_cyc_clt_rzr_cfg/$_sensor_hostname.rol.cfg 2>/dev/null )
[ -z "$_sensor_rzr_fam" ] && _sensor_status="DISABLE fam"

_sensor_status=$( crontab -l | awk 'BEGIN { _s="DISABLE cfg" } $0 ~ "cyc.host.ctrl.sh" && $0 ~ "daemon" { _s="UP" } END { print _s}' )
[ "$_sensor_status" == "UP" ] && _sensor_status=$( awk 'BEGIN { _s="MARK ini" } $0 ~ "cyc.host.ctrl.sh" && $0 ~ "boot" { _s="UP" } END { print _s }' /etc/rc.local 2>/dev/null )
[ "$_sensor_status" == "UP" ] && _sensor_status=$( [ -f "/opt/cyclops/local/lock/hctrl.disable" ] && echo "DISABLE off" || echo "UP" )
[ "$_sensor_status" == "UP" ] && _sensor_status=$( awk 'BEGIN { _s=0 } $0 !~ "^$" { _s+=1} END { if ( _s > 0 ) { print "OK "_s } else { print "DISABLE rzr"} }'  $_cyc_clt_rzr_cfg/$_sensor_rzr_fam.rzr.lst 2>/dev/null ) 

[ -z "$_sensor_status" ] && _sensor_status="MARK zero"

echo $_sensor_name":"$_sensor_status"@"
