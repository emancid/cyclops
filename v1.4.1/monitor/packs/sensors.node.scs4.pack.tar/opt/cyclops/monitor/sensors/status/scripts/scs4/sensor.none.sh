#!/bin/bash
#@HELP@ Empty Sensor to create correctly the monitor dashboard
#@SCOPY@
#@LOCAL@

_sensor_name="none"
_sensor_status="NONE"

source /etc/cyclops/global.cfg ## OWN EXEC ##

echo $_sensor_name":"$_sensor_status"@"
