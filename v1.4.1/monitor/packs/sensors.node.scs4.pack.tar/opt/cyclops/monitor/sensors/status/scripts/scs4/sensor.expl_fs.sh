#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@
#-O %fsname";"%status

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="expl_fs"
_sensor_status="CHECKING"

_fs_name="/expl"
_fs_mount=$( mount |  awk -v mount="$_fs_name" '$3 == mount { print "OK"}' ) 

if [ "$_fs_mount" == "OK" ] 
then 
	_fs_read=$( ls -1 $_fs_name 2>&1 >/dev/null ; echo $? ) 
	if [ "$_fs_read" -eq 0  ] 
	then
		 _fs_write=$( touch $_fs_name/cyclops.fs.test 2>&1 >/dev/null ; echo $? ) 
		if [ "$_fs_write" -eq 0 ]
		then
			_sensor_status="UP"
			rm $_fs_name/cyclops.fs.test 2>/dev/null >/dev/null
		else
			_sensort_status="FAIL can't write"
		fi
	else
		 _sensor_status="FAIL can't read"
	fi
else
	_sensor_status="FAIL not mount"
fi

echo $_sensor_name":"$_sensor_status"@"
