#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="ib_if"
_sensor_status="CHECKING"

_ib_if=$( ibstat 2>/dev/null | tr -d '\t' | egrep "State|Base\ lid" | tr '\n' ';' )
[ -z "$_ib_if" ] && _ib_if="::cmd err"

_ib_if_status=$( echo $_ib_if | grep -v Active | wc -l )

[ "$_ib_if_status" -eq 0 ] && _sensor_status="UP" || _sensor_status="DOWN "$( echo $_ib_if | awk -F\: '{ print $3 }' | sed 's/;$//' )

echo $_sensor_name":"$_sensor_status"@"
