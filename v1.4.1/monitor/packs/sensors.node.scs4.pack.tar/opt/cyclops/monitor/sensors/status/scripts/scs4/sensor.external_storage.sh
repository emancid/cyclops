#!/bin/bash
#@HELP@
#@SCOPY@
#@NODO@management
#@LOCAL@

_sensor_name="external_storage"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_storage=`storadm show 2>/dev/null | grep "^da" | awk '{ print $1"_"$7"_"$8"_"$9 }' | grep -v ok | wc -l`

if [ $_storage -eq 0 ]
then
	_sensor_status="UP"
else
	_sensor_status="DOWN "$_storage
fi

echo $_sensor_name":"$_sensor_status"@"
