#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="cpu"
_sensor_status="CHECKING"

_cpu=`mpstat 2 2 | awk '$1 ~ "^[a-zA-z]*:" { print $NF }' | sed 's/\...$//'`

let _cpu=100-$_cpu

if [ -z "$_cpu" ]
then
	_sensor_status="MARK sensor err"
else
	case "$_cpu" in
		[0-9]|[1-4][0-9])
			_sensor_status="UP $_cpu%"
		;;
		[5-6][0-9])
			_sensor_status="OK $_cpu%"
		;;
		100|[7-9][0-9])
			_sensor_status="CHECKING $_cpu%"
		;;
		*)
			_sensor_status="UNKNOWN"
		;;
		esac
fi

echo $_sensor_name":"$_sensor_status"@"
