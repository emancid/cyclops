#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="cpu0_temp_b7"
_sensor_status="CHECKING"

[ -z "$_ipmi_sensor" ] && _ipmi_sensor=$( ipmitool sensor )

_cpu_temp=$( echo "${_ipmi_sensor}" | awk -F\| '$1 ~ "CPU0 DTS value" { gsub(/ /,"",$2) ; if ( $2 ~ "^[-0-9.]+$" ) {  _tmp=$2+100 ; _max=$10+100 ; _total= ( _tmp * 100 ) / _max } else { _total=tolower($2)} } END { print _total }' | cut -d'.' -f1 )

case "$_cpu_temp" in
	[0-9]|[1-7][0-9])
		_sensor_status="UP $_cpu_temp%"
	;;
	8[0-9])
		_sensor_status="OK $_cpu_temp%"
	;;
	9[0-5])
		_sensor_status="MARK $_cpu_temp%"
	;;
	1[0-9][0-9]|9[6-9])
	_sensor_status="DOWN $_cpu_temp%"
	;;
	""|na)
	_sensor_status="DISABLE sensor miss"
	;;
	*)
	_sensor_status="UNKNOWN $_cpu_temp"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"

