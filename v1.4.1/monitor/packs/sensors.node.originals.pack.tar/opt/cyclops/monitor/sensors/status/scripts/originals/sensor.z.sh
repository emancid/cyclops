#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@
#PROCESS ZOMBIE DETECTOR

_sensor_name="z"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_ps_zombie=$( ps aux | awk '$8 == "Z" { if ( $10 ~ "[0-9][0-9]:[0-9][0-9]" ) { _zombie++ }} END { print _zombie }' 2>/dev/null ) 

case "$_ps_zombie" in
	[0-9]*)
		_sensor_status="FAIL $_ps_zombie"
	;;
        "")
                _sensor_status="UP"       
        ;;
	*)
		_sensor_status="UNKNOWN"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
