#!/bin/bash
#@HELP@ _net_list=`ip link | grep ^[0-9] | cut -d':' -f2 | sed 's/ //g'i | tr '\n' '|'`
#@SCOPY@$_monitor_path/sensors/status/conf/@NODO@.net.cfg $_sensor_remote_path/ 

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="network"
_sensor_status="CHECKING"

if [ -f "$_sensor_remote_path/$HOSTNAME.net.cfg" ]
then
	_net_list=$( cat $_sensor_remote_path/$HOSTNAME.net.cfg | tr '\n' '|' | sed -e 's/|$//')
	_net=`ip link | egrep ^.: | egrep "${_net_list}" | sed -e 's/.. \(.*\):.*state.\(.*\)/ \1 \2 /' | awk '{ print $1" "$2}' | grep DOWN | sed 's/DOWN//' | tr '\n' ' '`
	[ -z "$_net" ] && _sensor_status="UP" || _sensor_status="DOWN "$_net
else
	_sensor_status="DISABLE not configured"
fi

echo $_sensor_name":"$_sensor_status"@"
